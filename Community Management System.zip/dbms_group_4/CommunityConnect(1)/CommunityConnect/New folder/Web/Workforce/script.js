function redirectToPage(page) {
    console.log("Redirecting to page:", page);
    window.location.href = page;
}