function redirectToPage(page) {
    window.location.href = page;
}
